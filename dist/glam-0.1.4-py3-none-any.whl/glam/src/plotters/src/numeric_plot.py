"""Define the numeric_plot function."""

import plotly.graph_objects as go


def numeric_plot__plotly() -> go.Figure:
    """Create a plotly figure for a numeric plot."""
    return go.Figure()
