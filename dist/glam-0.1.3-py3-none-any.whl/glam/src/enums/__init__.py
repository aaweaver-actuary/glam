from glam.src.enums.model_type import ModelType
from glam.src.enums.model_task import ModelTask

__all__ = ["ModelType", "ModelTask"]
