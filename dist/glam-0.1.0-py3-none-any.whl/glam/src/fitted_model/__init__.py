from glam.src.fitted_model.base_fitted_model import BaseFittedModel
from glam.src.fitted_model.statsmodels_fitted_glm import StatsmodelsFittedGlm

__all__ = ["BaseFittedModel", "StatsmodelsFittedGlm"]
