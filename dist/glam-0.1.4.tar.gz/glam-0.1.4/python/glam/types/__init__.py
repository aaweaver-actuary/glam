from glam.types.glam_plot import GlamPlot

__all__ = ["GlamPlot"]
