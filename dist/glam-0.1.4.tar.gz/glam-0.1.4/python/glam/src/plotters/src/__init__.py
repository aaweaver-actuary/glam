from glam.src.plotters.src.categorical_plot import categorical_plot__plotly
from glam.src.plotters.src.numeric_plot import numeric_plot__plotly
from glam.src.plotters.src.residual_plot import residual_plot__plotly


__all__ = ["categorical_plot__plotly", "numeric_plot__plotly", "residual_plot__plotly"]
