"""Define the categorical_plot function."""

import plotly.graph_objects as go


def categorical_plot__plotly() -> go.Figure:
    """Create a plotly figure for a categorical plot."""
    return go.Figure()
